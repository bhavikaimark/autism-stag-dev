    <div class="twelve columns">
      <div class="row">
          <div class="five columns">
            <?php do_action('kleo_bp_search_form', (sq_option('home_search_members', '1') ==1?true:false) ); ?>   
          </div>
      </div><!--end row-->
    </div><!--end twelve-->